package com.example.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.entity.Category;
import com.example.repo.CatRepository;

@RestController
@RequestMapping("/category")
public class CategoryController {

	@Autowired
	private CatRepository catRepo;

	@GetMapping("/getAllCat")
	public ResponseEntity<List<Category>> getAllEmployees() {
		List<Category> catList = new ArrayList<>();
		catRepo.findAll().forEach(catList::add);
		return new ResponseEntity<List<Category>>(catList, HttpStatus.OK);
	}

	@PostMapping("/craeteCategory")
	public String craeteNewCategory(@RequestBody Category cat) {
		catRepo.save(cat);
		return "New Category Created";
	}

	@GetMapping("/getCatById/{id}")
	public ResponseEntity<Category> getCategoryById(@PathVariable Integer id) {
		Optional<Category> cat = catRepo.findById(id);
		if (cat.isPresent()) {
			return new ResponseEntity<Category>(cat.get(), HttpStatus.FOUND);
		} else {
			return new ResponseEntity<Category>(HttpStatus.NOT_FOUND);
		}
	}

	@DeleteMapping("/deleteCat/{id}")
	public String deleteCategoryById(@PathVariable Integer id) {
		catRepo.deleteById(id);
		return "Category Deleted successfully = " + id;
	}

	@PutMapping("/updateCat/{id}")
	public String updateCategoryById(@PathVariable Integer id, @RequestBody Category category) {
		Optional<Category> cat = catRepo.findById(id);
		if (cat.isPresent()) {
			Category existCat = cat.get();
			existCat.setId(category.getId());
			existCat.setCatName(category.getCatName());
			existCat.setLocation(category.getLocation());
			existCat.setQuantity(category.getQuantity());
			catRepo.save(existCat);
			return "Category Details are updated of " + id;
		} else {
			return "not found" + id;
		}
	}
	
	@DeleteMapping("/deleteAllCat")
	public String deleteallCatageory() {
		catRepo.deleteAll();
		return "All Category Deleted";
	}


}
