package com.example.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Table(name = "Product")
@Entity
public class Product {

	private String productName;

	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getId() {
		return id;
	}

	
	public String getCatName() {
		return productName;
	}

	public void setCatName(String catName) {
		this.productName = catName;
	}

	public String getQuantity() {
		return quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	

	public Product(int id, String productName, String quantity, String location) {
		super();
		this.id = id;
		this.productName = productName;
		this.quantity = quantity;
		this.location = location;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;

	private String quantity;

	private String location;
}
