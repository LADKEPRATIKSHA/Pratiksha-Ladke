package com.example.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.entity.Category;
import com.example.entity.Product;
import com.example.repo.CatRepository;
import com.example.repo.ProductRepository;

@RestController
@RequestMapping("/product")
public class ProductController {

	@Autowired
	private ProductRepository productRepo;

	@GetMapping("/getAllProduct")
	public ResponseEntity<List<Product>> getAllEmployees() {
		List<Product> productList = new ArrayList<>();
		productRepo.findAll().forEach(productList::add);
		return new ResponseEntity<List<Product>>(productList, HttpStatus.OK);
	}

	@PostMapping("/craeteProduct")
	public String craeteNewProduct(@RequestBody Product product) {
		productRepo.save(product);
		return "New Product Created";
	}

	@GetMapping("/getProductById/{id}")
	public ResponseEntity<Product> getProductById(@PathVariable Integer id) {
		Optional<Product> product = productRepo.findById(id);
		if (product.isPresent()) {
			return new ResponseEntity<Product>(product.get(), HttpStatus.FOUND);
		} else {
			return new ResponseEntity<Product>(HttpStatus.NOT_FOUND);
		}
	}

	@DeleteMapping("/deleteProduct/{id}")
	public String deleteProductById(@PathVariable Integer id) {
		productRepo.deleteById(id);
		return "Product Deleted successfully = " + id;
	}

//	@PutMapping("/updateProduct/{id}")
//	public String updateProductById(@PathVariable Integer id, @RequestBody Product product) {
//		Optional<Product> product = productRepo.findById(id);
//		if (product.isPresent()) {
//			Product existProduct= product.get();
//			existProduct.setId(product.get());
//			existProduct.setProductName(product.getProductName());
//			existProduct.setLocation(product.getLocation());
//			existProduct.setQuantity(product.getQuantity());
//			productRepo.save(existProduct);
//			return " Product Details are updated of " + id;
//		} else {
//			return "not found" + id;
//		}
//	}
	
	@DeleteMapping("/deleteAllProduct")
	public String deleteallProduct() {
		productRepo.deleteAll();
		return "All Product Deleted";
	}

}
